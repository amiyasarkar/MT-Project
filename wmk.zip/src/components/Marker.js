import { Watermark } from "@hirohe/react-watermark";
import Page from "./Page";
import * as React from "react";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import ListSubheader from "@mui/material/ListSubheader";
import Switch from "@mui/material/Switch";
import Brightness4Icon from "@mui/icons-material/Brightness4";
import AutofpsSelectIcon from "@mui/icons-material/AutofpsSelect";
import { Button } from "@mui/material";

function Marker(props) {
  const [checked, setChecked] = React.useState([]);
  const [show, setShow] = React.useState(true);
  function SwitchListSecondary() {
    console.log(checked);

    const handleToggle = value => () => {
      const currentIndex = checked.indexOf(value);
      const newChecked = [...checked];

      if (currentIndex === -1) {
        newChecked.push(value);
      } else {
        newChecked.splice(currentIndex, 1);
      }
      setChecked(newChecked);
      console.log(checked);
      if (checked.includes("watermark")) {
        setShow(true);
      } else {
        setShow(!show);
      }
    };

    return (
      <List
        sx={{ bgcolor: "background.paper" }}
        subheader={<ListSubheader>App Settings</ListSubheader>}
      >
        <ListItem>
          <ListItemIcon>
            <Brightness4Icon />
          </ListItemIcon>
          <ListItemText
            id="switch-list-label-darkbg"
            primary="Enable Dark Background"
          />
          <Switch
            edge="end"
            onChange={handleToggle("darkbg")}
            checked={checked.indexOf("darkbg") !== -1}
            inputProps={{
              "aria-labelledby": "switch-list-label-darkbg"
            }}
          />
        </ListItem>
        <ListItem>
          <ListItemIcon>
            <AutofpsSelectIcon />
          </ListItemIcon>
          <ListItemText id="switch-list-label-watermark" primary="Watermark" />
          <Button
            variant="contained"
            size="small"
            edge="end"
            onClick={handleToggle("watermark")}
            checked={checked.indexOf("watermark") === -1}
            inputProps={{
              "aria-labelledby": "switch-list-label-watermark"
            }}
          >
            Refresh
          </Button>
        </ListItem>
      </List>
    );
  }
  return (
    <>
      <SwitchListSecondary />
      <Watermark
        show={show}
        multiline={true}
        opacity="0.1"
        fontFamily="Corbel"
        textSize={30}
        text={props.text}
      >
        {checked.includes("darkbg") && (
          <div style={{ height: 500, backgroundColor: "#5f5f5f" }}>
            <Page />
          </div>
        )}
        {!checked.includes("darkbg") && (
          <div style={{ height: 500 }}>
            <Page />
          </div>
        )}
      </Watermark>
    </>
  );
}

export default Marker;
