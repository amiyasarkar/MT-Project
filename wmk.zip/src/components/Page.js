import { Card } from "@mui/material";

export default function Page() {
  return (
    <>
      {/* <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTws7wqubNJ85t-jugtbkyc-Im7L0mlb7aWzP68FT4&s" /> */}
      I am amiya sarkar. I like to eat some wine
    </>
  );
}
