import Marker from "./components/Marker";

function App() {
  return <Marker text="Amiya Sarkar 2023" />;
}

export default App;
